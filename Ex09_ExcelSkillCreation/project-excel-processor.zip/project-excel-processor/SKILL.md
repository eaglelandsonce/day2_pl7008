---
name: project-excel-processor
description: Standardizes, validates and summarizes project-tracking Excel workbooks that contain a `Projects` worksheet (Project ID, Project Name, Department, Status, Budget, Actual Cost, Due Date, Owner). Normalizes departments/statuses, parses USD amounts and dates, computes variance, budget and overdue flags, flags data-quality issues without deleting rows, and writes a new workbook (`Projects_Processed.xlsx`) with `Processed_Results` and `Processing_Summary` tabs while leaving `Projects` untouched. Use when asked to process, clean, validate or summarize a projects workbook with this schema.
---

# project-excel-processor

## When to use (triggers)
- "Use the project-excel-processor skill to process …", or any request to clean, normalize,
  validate, flag over-budget/overdue items, or summarize exceptions in an `.xlsx` that has a
  `Projects` worksheet with the schema below.
- Do **not** use for workbooks lacking a `Projects` sheet or the required columns — report the
  schema mismatch instead (the script exits with code 2 and names the missing columns).

## Inputs
| Input | Required | Notes |
|---|---|---|
| `.xlsx` workbook | yes | Sheet `Projects`; header in row 1. Required columns (case/whitespace-insensitive, any order): Project ID, Project Name, Department, Status, Budget, Actual Cost, Due Date, Owner. Extra columns are ignored. |
| As-of (evaluation) date | yes for reproducible runs | `--as-of YYYY-MM-DD`. Use `2026-11-16` for the reference example. If the user gives none, the script defaults to today (UTC) — state that in your reply. |
| Requirements | reference | `references/Requirements.md` holds the business rules this script implements. |

## Package layout
```
project-excel-processor/
├── SKILL.md                    # this file: agent orchestration
├── references/Requirements.md  # business rules + acceptance tests
└── scripts/
    ├── process_projects.py     # deterministic processor (all rules live here)
    └── test_acceptance.py      # acceptance + idempotency tests
```
Separation of concerns: **all transformation logic is in `process_projects.py`** (pure,
deterministic, no LLM judgement). The agent only locates files, picks the as-of date, runs
the scripts, checks results, and writes the natural-language summary. Never hand-edit
result cells or re-implement rules in ad-hoc code.

## Procedure
1. **Locate inputs.** Find the uploaded workbook and requirements file. If the requirements
   file differs materially from `references/Requirements.md` (new mappings/rules), tell the
   user and update the mapping tables at the top of `process_projects.py` before running.
2. **Run the processor** (requires Python 3.9+ and `openpyxl`):
   ```bash
   python scripts/process_projects.py INPUT.xlsx -o OUTDIR/Projects_Processed.xlsx \
       --as-of 2026-11-16 --report-json OUTDIR/run_report.json
   ```
   - Output defaults to `Projects_Processed.xlsx` beside the input. The output path must
     differ from the input; the input file is never written.
3. **Run acceptance tests** (for the reference example, or after any code change):
   ```bash
   python scripts/test_acceptance.py INPUT.xlsx --as-of 2026-11-16
   ```
   The P-0xx assertions are specific to the example data; for other files rely on the
   built-in post-write validation (step 4) and the generic checks.
4. **Check validation.** The processor re-opens its output and asserts:
   `projects_sheet_unchanged`, `single_results_tab`, `single_summary_tab`,
   `results_headers_ok`, `row_count_preserved`, `every_row_has_issue_text`.
   Any failure → exit code 3; do not deliver the file, investigate and fix.
5. **Report to the user** from the console output / `run_report.json`: totals (projects,
   with issues, over budget, overdue), the as-of date used, and every exception row
   (row, Project ID, issues). Attach the workbook.

## Transformation rules (implemented in the script)
- **Department:** `IT/technology/Information Technology/tech → IT`;
  `HR/human resources/Human Resources → Human Resources`; `Sales → Sales`
  (case/whitespace-insensitive). Unknown → value kept, issue `Unknown Department '<v>'`.
- **Status:** case/whitespace/hyphen-insensitive: `in progress → In Progress`;
  `completed/complete/done → Completed`; `not started → Not Started`; `at risk → At Risk`;
  `blocked → Blocked`. Otherwise `Needs Review` + issue `Invalid Status '<v>'`.
- **Budget / Actual Cost:** numbers or strings with `$`, commas (thousands grouping only),
  spaces. Blank → `Missing <field>`; unparseable → `Invalid <field> '<v>'`; never coerced to
  0. A genuine `0`/`$0` is valid.
- **Due Date:** `YYYY-MM-DD`, `YYYY/MM/DD`, `MM/DD/YYYY` or native Excel dates. Blank →
  `Missing Due Date`; otherwise invalid (incl. impossible dates like 02/30) →
  `Invalid Due Date '<v>'`.
- **Variance** = Budget − Actual Cost (negative = over budget). **Budget Flag**:
  `Over Budget` if Actual > Budget, `Within Budget` otherwise, `Missing Data` if either
  amount is unusable.
- **Overdue:** `Yes` if Due Date < as-of date and Status ≠ Completed; `No` otherwise;
  `Unknown` if date missing/invalid.
- **Required identity fields:** `Missing Project ID`, `Missing Project Name`,
  `Missing Owner`; duplicated IDs → `Duplicate Project ID '<id>'`.
- Issues joined with `; `; a clean row shows `OK`. Fully blank physical rows are skipped;
  every other row is kept.

## Outputs
- `Projects_Processed.xlsx` (new copy of the input):
  - `Projects` — original sheet, unchanged (verified cell-by-cell).
  - `Processed_Results` — Source Row, Project ID, Project Name, Department, Status, Budget,
    Actual Cost, Variance, Budget Flag, Due Date, Overdue, Owner, Issue Count,
    Data Quality Issues. Currency format `$#,##0.00` (negatives red), dates `yyyy-mm-dd`,
    styled header, frozen panes, autofilter; amber rows = issues, red cell = Over Budget,
    orange = Overdue.
  - `Processing_Summary` — source file, evaluation date, processing timestamp (UTC), total
    projects, projects with issues / OK, over-budget, missing budget data, overdue, unknown
    overdue, issue-type breakdown, and an exceptions table.
- Optional `run_report.json` — same summary plus exception/over-budget/overdue lists and
  validation results, for the agent's narrative.

## Safety rules
- Never modify or overwrite the input workbook or its `Projects` sheet; always write a new file.
- Never delete, filter out, or silently "fix" invalid rows — flag them.
- Never treat blank/invalid amounts as zero, or guess dates in ambiguous formats
  (e.g. `DD/MM/YYYY` is flagged, not reinterpreted).
- Re-runs replace `Processed_Results`/`Processing_Summary`; never create duplicates.
- Always state the as-of date used; overdue results depend on it.
- Do not upload workbook contents to external services.

## Validation checklist (before replying)
- [ ] Script exit code 0 and all six validation checks `True`.
- [ ] Row count in `Processed_Results` equals non-blank source rows.
- [ ] For the example file: `test_acceptance.py` reports all checks PASS.
- [ ] Summary reply lists every exception row and the as-of date.
