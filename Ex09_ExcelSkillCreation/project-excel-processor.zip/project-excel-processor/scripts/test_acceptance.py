#!/usr/bin/env python3
"""Acceptance tests for process_projects.py (from references/Requirements.md).

Usage: python test_acceptance.py INPUT.xlsx [--as-of 2026-11-16] [--keep OUT.xlsx]
Runs the processor into a temp dir, checks every acceptance criterion plus
idempotent re-run behaviour, and exits non-zero on any failure.
The P-0xx checks are specific to the reference example workbook.
"""
import argparse
import sys
import tempfile
from pathlib import Path

from openpyxl import load_workbook

sys.path.insert(0, str(Path(__file__).resolve().parent))
import process_projects as pp  # noqa: E402


def rows_by_id(path):
    ws = load_workbook(path)[pp.RESULTS_SHEET]
    hdr = [c.value for c in ws[1]]
    return {r[hdr.index("Project ID")]: dict(zip(hdr, r))
            for r in ws.iter_rows(min_row=2, values_only=True)}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("input")
    ap.add_argument("--as-of", default="2026-11-16")
    ap.add_argument("--keep", help="Copy the tested output workbook here")
    a = ap.parse_args()
    from datetime import date
    as_of = date.fromisoformat(a.as_of)

    results = []

    def check(name, cond, detail=""):
        results.append(cond)
        print(f"[{'PASS' if cond else 'FAIL'}] {name}" + (f" -- {detail}" if detail and not cond else ""))

    with tempfile.TemporaryDirectory() as td:
        out = Path(td) / pp.DEFAULT_OUTPUT_NAME
        src_before = pp.snapshot_sheet(load_workbook(a.input)[pp.SOURCE_SHEET])
        pp.process_workbook(a.input, out, as_of)
        rows = rows_by_id(out)

        p2 = rows.get("P-002", {})
        check("P-002 status Completed and variance -2400",
              p2.get("Status") == "Completed" and p2.get("Variance") == -2400, str(p2))
        p4 = rows.get("P-004", {})
        check("P-004 overdue as of 2026-11-16", p4.get("Overdue") == "Yes", str(p4))
        p8 = rows.get("P-008", {})
        check("P-008 Needs Review with invalid-status issue",
              p8.get("Status") == "Needs Review" and "Invalid Status" in (p8.get("Data Quality Issues") or ""), str(p8))
        p10 = rows.get("P-010", {})
        check("P-010 budget flag Missing Data", p10.get("Budget Flag") == "Missing Data", str(p10))
        p11 = rows.get("P-011", {})
        check("P-011 invalid-date issue", "Invalid Due Date" in (p11.get("Data Quality Issues") or ""), str(p11))
        p12 = rows.get("P-012", {})
        check("P-012 missing owner flagged", "Missing Owner" in (p12.get("Data Quality Issues") or ""), str(p12))

        out_wb = load_workbook(out)
        proj_after = pp.snapshot_sheet(out_wb[pp.SOURCE_SHEET])
        check("Original Projects sheet intact (12 data rows, identical values)",
              proj_after == src_before and len(proj_after) - 1 == 12, f"{len(proj_after) - 1} rows")
        check("Input file itself not modified",
              pp.snapshot_sheet(load_workbook(a.input)[pp.SOURCE_SHEET]) == src_before)
        check("Processed_Results has 12 rows", out_wb[pp.RESULTS_SHEET].max_row - 1 == 12)
        check("Sheet set is Projects/Processed_Results/Processing_Summary",
              out_wb.sheetnames == [pp.SOURCE_SHEET, pp.RESULTS_SHEET, pp.SUMMARY_SHEET], str(out_wb.sheetnames))
        ok_values = all(r["Data Quality Issues"] for r in rows.values())
        check("Every row has issues text or OK", ok_values)
        check("Valid numeric zero accepted (P-003 actual cost = 0, no issue)",
              rows["P-003"]["Actual Cost"] == 0 and rows["P-003"]["Data Quality Issues"] == "OK", str(rows["P-003"]))

        # Re-run on the already-processed workbook: tabs replaced, not duplicated.
        out2 = Path(td) / "rerun.xlsx"
        pp.process_workbook(out, out2, as_of)
        names = load_workbook(out2).sheetnames
        check("Re-run replaces result tabs (no duplicates)",
              names == [pp.SOURCE_SHEET, pp.RESULTS_SHEET, pp.SUMMARY_SHEET], str(names))
        check("Re-run results identical", rows_by_id(out2) == rows)

        if a.keep:
            import shutil
            shutil.copyfile(out, a.keep)

    passed = sum(results)
    print(f"\n{passed}/{len(results)} checks passed")
    return 0 if all(results) else 1


if __name__ == "__main__":
    sys.exit(main())
