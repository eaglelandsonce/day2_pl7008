#!/usr/bin/env python3
"""Deterministic processor for project-tracking workbooks.

Reads the `Projects` worksheet of an .xlsx file, standardizes and validates
every row, and writes a NEW workbook that contains:
  * `Projects`            - the original worksheet, byte-for-byte untouched
  * `Processed_Results`   - one standardized row per source row (no deletions)
  * `Processing_Summary`  - headline counts, issue breakdown and exceptions

The script never modifies the input file. Re-running against a workbook that
already contains result tabs replaces those tabs instead of duplicating them.

Usage:
  python process_projects.py INPUT.xlsx [-o OUTPUT.xlsx] [--as-of YYYY-MM-DD]
                             [--report-json REPORT.json]

Exit codes: 0 success, 2 schema/input error, 3 post-write validation failure.
"""
from __future__ import annotations

import argparse
import json
import re
import shutil
import sys
from collections import Counter
from datetime import date, datetime, timezone
from decimal import Decimal, InvalidOperation
from pathlib import Path

from openpyxl import load_workbook
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.utils import get_column_letter

SOURCE_SHEET = "Projects"
RESULTS_SHEET = "Processed_Results"
SUMMARY_SHEET = "Processing_Summary"
DEFAULT_OUTPUT_NAME = "Projects_Processed.xlsx"

REQUIRED_COLUMNS = [
    "Project ID", "Project Name", "Department", "Status",
    "Budget", "Actual Cost", "Due Date", "Owner",
]

# ---- Normalization tables (keys are lower-case, whitespace-collapsed) ----
DEPARTMENT_MAP = {
    "it": "IT",
    "technology": "IT",
    "information technology": "IT",
    "tech": "IT",
    "hr": "Human Resources",
    "human resources": "Human Resources",
    "sales": "Sales",
}
STATUS_MAP = {
    "in progress": "In Progress",
    "completed": "Completed",
    "complete": "Completed",
    "done": "Completed",
    "not started": "Not Started",
    "at risk": "At Risk",
    "blocked": "Blocked",
}
NEEDS_REVIEW = "Needs Review"

DATE_PATTERNS = [  # (regex, strptime format)
    (re.compile(r"^\d{4}-\d{1,2}-\d{1,2}$"), "%Y-%m-%d"),
    (re.compile(r"^\d{4}/\d{1,2}/\d{1,2}$"), "%Y/%m/%d"),
    (re.compile(r"^\d{1,2}/\d{1,2}/\d{4}$"), "%m/%d/%Y"),
]
CURRENCY_RE = re.compile(r"^-?(\d{1,3}(,\d{3})+|\d+)(\.\d+)?$")  # commas only as thousands separators

RESULT_HEADERS = [
    "Source Row", "Project ID", "Project Name", "Department", "Status",
    "Budget", "Actual Cost", "Variance", "Budget Flag", "Due Date",
    "Overdue", "Owner", "Issue Count", "Data Quality Issues",
]
CURRENCY_FMT = '"$"#,##0.00;[Red]-"$"#,##0.00'
DATE_FMT = "yyyy-mm-dd"

HEADER_FILL = PatternFill("solid", fgColor="1F4E78")
HEADER_FONT = Font(bold=True, color="FFFFFF")
ISSUE_FILL = PatternFill("solid", fgColor="FFF2CC")      # light amber row
ISSUE_CELL_FILL = PatternFill("solid", fgColor="FFD966")  # issue text cell
OVER_FILL = PatternFill("solid", fgColor="F8CBAD")        # over budget
OVER_FONT = Font(bold=True, color="9C0006")
OVERDUE_FILL = PatternFill("solid", fgColor="F4B084")
OK_FONT = Font(color="006100")
THIN = Side(style="thin", color="BFBFBF")
BORDER = Border(left=THIN, right=THIN, top=THIN, bottom=THIN)


class SchemaError(Exception):
    """Raised when the input workbook does not match the required schema."""


# --------------------------------------------------------------------------
# Pure parsing helpers (deterministic, no I/O)
# --------------------------------------------------------------------------
def _clean_text(value) -> str:
    if value is None:
        return ""
    return re.sub(r"\s+", " ", str(value)).strip()


def _key(value) -> str:
    return _clean_text(value).lower()


def normalize_department(value):
    """Return (normalized_value, issue_or_None)."""
    text = _clean_text(value)
    if not text:
        return "", "Missing Department"
    mapped = DEPARTMENT_MAP.get(text.lower())
    if mapped:
        return mapped, None
    return text, f"Unknown Department '{text}'"


def normalize_status(value):
    """Case/whitespace/hyphen-insensitive status normalization."""
    text = _clean_text(value)
    if not text:
        return NEEDS_REVIEW, "Missing Status"
    key = re.sub(r"\s+", " ", text.lower().replace("-", " ").replace("_", " ")).strip()
    mapped = STATUS_MAP.get(key)
    if mapped:
        return mapped, None
    return NEEDS_REVIEW, f"Invalid Status '{text}'"


def parse_currency(value, label):
    """Return (Decimal_or_None, issue_or_None). Blank/invalid never become 0."""
    if value is None or (isinstance(value, str) and not value.strip()):
        return None, f"Missing {label}"
    if isinstance(value, bool):
        return None, f"Invalid {label} '{value}'"
    if isinstance(value, (int, float, Decimal)):
        return Decimal(str(value)), None
    text = re.sub(r"\s+", "", str(value))
    text = re.sub(r"(?i)usd", "", text)
    text = re.sub(r"^(-?)\$", r"\1", text)  # "$1,000" or "-$1,000"
    if not CURRENCY_RE.match(text):
        return None, f"Invalid {label} '{_clean_text(value)}'"
    try:
        return Decimal(text.replace(",", "")), None
    except InvalidOperation:  # pragma: no cover - regex already guards
        return None, f"Invalid {label} '{_clean_text(value)}'"


def parse_due_date(value):
    """Return (date_or_None, issue_or_None)."""
    if value is None or (isinstance(value, str) and not value.strip()):
        return None, "Missing Due Date"
    if isinstance(value, datetime):
        return value.date(), None
    if isinstance(value, date):
        return value, None
    text = str(value).strip()
    for pattern, fmt in DATE_PATTERNS:
        if pattern.match(text):
            try:
                return datetime.strptime(text, fmt).date(), None
            except ValueError:
                break  # right shape, impossible calendar date
    return None, f"Invalid Due Date '{_clean_text(value)}'"


def process_row(raw: dict, as_of: date) -> dict:
    """Apply every transformation rule to one source row."""
    issues = []

    pid = _clean_text(raw.get("Project ID"))
    name = _clean_text(raw.get("Project Name"))
    owner = _clean_text(raw.get("Owner"))
    if not pid:
        issues.append("Missing Project ID")
    if not name:
        issues.append("Missing Project Name")
    if not owner:
        issues.append("Missing Owner")

    dept, issue = normalize_department(raw.get("Department"))
    issue and issues.append(issue)
    status, issue = normalize_status(raw.get("Status"))
    issue and issues.append(issue)
    budget, issue = parse_currency(raw.get("Budget"), "Budget")
    issue and issues.append(issue)
    actual, issue = parse_currency(raw.get("Actual Cost"), "Actual Cost")
    issue and issues.append(issue)
    due, issue = parse_due_date(raw.get("Due Date"))
    issue and issues.append(issue)

    if budget is not None and actual is not None:
        variance = budget - actual
        budget_flag = "Over Budget" if actual > budget else "Within Budget"
    else:
        variance = None
        budget_flag = "Missing Data"

    if due is None:
        overdue = "Unknown"
    elif due < as_of and status != "Completed":
        overdue = "Yes"
    else:
        overdue = "No"

    return {
        "Project ID": pid,
        "Project Name": name,
        "Department": dept,
        "Status": status,
        "Budget": budget,
        "Actual Cost": actual,
        "Variance": variance,
        "Budget Flag": budget_flag,
        "Due Date": due,
        "Overdue": overdue,
        "Owner": owner,
        "issues": issues,
    }


# --------------------------------------------------------------------------
# Workbook I/O
# --------------------------------------------------------------------------
def read_source(ws):
    """Locate headers (row 1, tolerant of case/whitespace) and return rows."""
    header_cells = [c.value for c in ws[1]]
    lookup = {_key(h): idx for idx, h in enumerate(header_cells) if _key(h)}
    missing = [c for c in REQUIRED_COLUMNS if c.lower() not in lookup]
    if missing:
        raise SchemaError(
            f"Worksheet '{SOURCE_SHEET}' is missing required column(s): {', '.join(missing)}"
        )
    col_idx = {c: lookup[c.lower()] for c in REQUIRED_COLUMNS}
    rows = []
    for r_idx, row in enumerate(ws.iter_rows(min_row=2, values_only=True), start=2):
        if row is None or all(v is None or (isinstance(v, str) and not v.strip()) for v in row):
            continue  # fully blank physical row, not a project
        raw = {c: (row[i] if i < len(row) else None) for c, i in col_idx.items()}
        rows.append((r_idx, raw))
    return rows


def snapshot_sheet(ws):
    return [tuple(c.value for c in row) for row in ws.iter_rows()]


def _to_number(d):
    if d is None:
        return None
    return int(d) if d == d.to_integral_value() else float(d)


def write_results(wb, results):
    if RESULTS_SHEET in wb.sheetnames:
        del wb[RESULTS_SHEET]
    ws = wb.create_sheet(RESULTS_SHEET)
    ws.append(RESULT_HEADERS)
    for src_row, rec in results:
        issues = rec["issues"]
        ws.append([
            src_row, rec["Project ID"] or None, rec["Project Name"] or None,
            rec["Department"] or None, rec["Status"],
            _to_number(rec["Budget"]), _to_number(rec["Actual Cost"]),
            _to_number(rec["Variance"]), rec["Budget Flag"], rec["Due Date"],
            rec["Overdue"], rec["Owner"] or None, len(issues),
            "; ".join(issues) if issues else "OK",
        ])
    col = {h: i + 1 for i, h in enumerate(RESULT_HEADERS)}
    for cell in ws[1]:
        cell.fill, cell.font, cell.border = HEADER_FILL, HEADER_FONT, BORDER
        cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
    for r in range(2, ws.max_row + 1):
        has_issue = ws.cell(r, col["Issue Count"]).value > 0
        for c in range(1, len(RESULT_HEADERS) + 1):
            cell = ws.cell(r, c)
            cell.border = BORDER
            if has_issue:
                cell.fill = ISSUE_FILL
        for h in ("Budget", "Actual Cost", "Variance"):
            ws.cell(r, col[h]).number_format = CURRENCY_FMT
        ws.cell(r, col["Due Date"]).number_format = DATE_FMT
        flag = ws.cell(r, col["Budget Flag"])
        if flag.value == "Over Budget":
            flag.fill, flag.font = OVER_FILL, OVER_FONT
            ws.cell(r, col["Variance"]).fill = OVER_FILL
        elif flag.value == "Missing Data":
            flag.fill = ISSUE_CELL_FILL
        od = ws.cell(r, col["Overdue"])
        if od.value == "Yes":
            od.fill, od.font = OVERDUE_FILL, Font(bold=True)
        elif od.value == "Unknown":
            od.fill = ISSUE_CELL_FILL
        dq = ws.cell(r, col["Data Quality Issues"])
        if has_issue:
            dq.fill, dq.font = ISSUE_CELL_FILL, Font(bold=True, color="7F6000")
        else:
            dq.font = OK_FONT
        dq.alignment = Alignment(wrap_text=True, vertical="top")
    widths = {"Source Row": 10, "Project ID": 11, "Project Name": 22, "Department": 18,
              "Status": 14, "Budget": 14, "Actual Cost": 14, "Variance": 14,
              "Budget Flag": 15, "Due Date": 12, "Overdue": 10, "Owner": 14,
              "Issue Count": 11, "Data Quality Issues": 48}
    for h, w in widths.items():
        ws.column_dimensions[get_column_letter(col[h])].width = w
    ws.freeze_panes = "C2"
    ws.auto_filter.ref = ws.dimensions
    return ws


def build_summary(results, as_of, run_ts, source_name):
    issues_rows = [(s, r) for s, r in results if r["issues"]]
    issue_types = Counter()
    for _, r in results:
        for i in r["issues"]:
            issue_types[re.sub(r"\s*'.*'$", "", i)] += 1
    return {
        "source_file": source_name,
        "evaluation_date": as_of.isoformat(),
        "processed_at_utc": run_ts,
        "total_projects": len(results),
        "projects_with_issues": len(issues_rows),
        "projects_ok": len(results) - len(issues_rows),
        "over_budget_projects": sum(r["Budget Flag"] == "Over Budget" for _, r in results),
        "missing_budget_data_projects": sum(r["Budget Flag"] == "Missing Data" for _, r in results),
        "overdue_projects": sum(r["Overdue"] == "Yes" for _, r in results),
        "overdue_unknown_projects": sum(r["Overdue"] == "Unknown" for _, r in results),
        "issue_type_counts": dict(sorted(issue_types.items())),
        "exceptions": [
            {"source_row": s, "project_id": r["Project ID"], "project_name": r["Project Name"],
             "status": r["Status"], "budget_flag": r["Budget Flag"], "overdue": r["Overdue"],
             "issues": "; ".join(r["issues"])}
            for s, r in issues_rows
        ],
        "over_budget": [
            {"source_row": s, "project_id": r["Project ID"], "variance": _to_number(r["Variance"])}
            for s, r in results if r["Budget Flag"] == "Over Budget"
        ],
        "overdue": [
            {"source_row": s, "project_id": r["Project ID"], "status": r["Status"],
             "due_date": r["Due Date"].isoformat()}
            for s, r in results if r["Overdue"] == "Yes"
        ],
    }


def write_summary(wb, summary):
    if SUMMARY_SHEET in wb.sheetnames:
        del wb[SUMMARY_SHEET]
    ws = wb.create_sheet(SUMMARY_SHEET)
    bold = Font(bold=True)

    def header(row, labels):
        for i, lbl in enumerate(labels, start=1):
            c = ws.cell(row, i, lbl)
            c.fill, c.font, c.border = HEADER_FILL, HEADER_FONT, BORDER

    ws.cell(1, 1, "Project Processing Summary").font = Font(bold=True, size=14)
    header(3, ["Metric", "Value"])
    metrics = [
        ("Source file", summary["source_file"]),
        ("Evaluation (as-of) date", date.fromisoformat(summary["evaluation_date"])),
        ("Processing date (UTC run time)", summary["processed_at_utc"]),
        ("Total projects", summary["total_projects"]),
        ("Projects with issues", summary["projects_with_issues"]),
        ("Projects without issues (OK)", summary["projects_ok"]),
        ("Over-budget projects", summary["over_budget_projects"]),
        ("Projects with missing budget data", summary["missing_budget_data_projects"]),
        ("Overdue projects", summary["overdue_projects"]),
        ("Projects with unknown overdue state", summary["overdue_unknown_projects"]),
    ]
    r = 4
    for label, value in metrics:
        ws.cell(r, 1, label).border = BORDER
        v = ws.cell(r, 2, value)
        v.border = BORDER
        v.alignment = Alignment(horizontal="left")
        if isinstance(value, date):
            v.number_format = DATE_FMT
        if label in ("Projects with issues", "Over-budget projects", "Overdue projects") and value:
            v.font = bold
            v.fill = ISSUE_CELL_FILL if label == "Projects with issues" else OVER_FILL
        r += 1

    r += 1
    ws.cell(r, 1, "Issue type breakdown").font = bold
    r += 1
    header(r, ["Issue type", "Rows"])
    r += 1
    if summary["issue_type_counts"]:
        for k, v in summary["issue_type_counts"].items():
            ws.cell(r, 1, k).border = BORDER
            ws.cell(r, 2, v).border = BORDER
            r += 1
    else:
        ws.cell(r, 1, "None"); r += 1

    r += 1
    ws.cell(r, 1, "Exceptions (rows with data quality issues)").font = bold
    r += 1
    header(r, ["Source Row", "Project ID", "Project Name", "Status", "Budget Flag",
               "Overdue", "Issues"])
    r += 1
    if summary["exceptions"]:
        for e in summary["exceptions"]:
            vals = [e["source_row"], e["project_id"] or "(blank)", e["project_name"] or "(blank)",
                    e["status"], e["budget_flag"], e["overdue"], e["issues"]]
            for i, v in enumerate(vals, start=1):
                c = ws.cell(r, i, v)
                c.border, c.fill = BORDER, ISSUE_FILL
            r += 1
    else:
        ws.cell(r, 1, "None"); r += 1

    for letter, w in zip("ABCDEFG", (36, 30, 22, 14, 15, 10, 48)):
        ws.column_dimensions[letter].width = w
    return ws


def process_workbook(input_path, output_path, as_of, report_json=None):
    input_path, output_path = Path(input_path), Path(output_path)
    if not input_path.is_file():
        raise SchemaError(f"Input file not found: {input_path}")
    if input_path.suffix.lower() != ".xlsx":
        raise SchemaError("Input must be an .xlsx workbook")
    if input_path.resolve() == output_path.resolve():
        raise SchemaError("Output path must differ from input; the input is never overwritten")

    src_wb = load_workbook(input_path)  # read-only use: never saved
    if SOURCE_SHEET not in src_wb.sheetnames:
        raise SchemaError(f"Worksheet '{SOURCE_SHEET}' not found (sheets: {src_wb.sheetnames})")
    original_snapshot = snapshot_sheet(src_wb[SOURCE_SHEET])
    rows = read_source(src_wb[SOURCE_SHEET])

    results = [(r_idx, process_row(raw, as_of)) for r_idx, raw in rows]
    ids = Counter(r["Project ID"] for _, r in results if r["Project ID"])
    for _, r in results:
        if r["Project ID"] and ids[r["Project ID"]] > 1:
            r["issues"].append(f"Duplicate Project ID '{r['Project ID']}'")

    # New copy of the workbook: the Projects sheet is carried over untouched.
    output_path.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(input_path, output_path)
    out_wb = load_workbook(output_path)
    run_ts = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S UTC")
    write_results(out_wb, results)
    summary = build_summary(results, as_of, run_ts, input_path.name)
    write_summary(out_wb, summary)
    out_wb.active = out_wb.sheetnames.index(RESULTS_SHEET)
    out_wb.save(output_path)

    checks = validate_output(output_path, original_snapshot, len(results))
    summary["validation"] = checks
    summary["output_file"] = str(output_path)
    if report_json:
        Path(report_json).write_text(json.dumps(summary, indent=2, default=str))
    return summary


def validate_output(output_path, original_snapshot, expected_rows):
    wb = load_workbook(output_path)
    checks = {}
    checks["projects_sheet_unchanged"] = snapshot_sheet(wb[SOURCE_SHEET]) == original_snapshot
    checks["single_results_tab"] = wb.sheetnames.count(RESULTS_SHEET) == 1
    checks["single_summary_tab"] = wb.sheetnames.count(SUMMARY_SHEET) == 1
    res = wb[RESULTS_SHEET]
    checks["results_headers_ok"] = [c.value for c in res[1]] == RESULT_HEADERS
    checks["row_count_preserved"] = (res.max_row - 1) == expected_rows
    issue_col = RESULT_HEADERS.index("Data Quality Issues") + 1
    checks["every_row_has_issue_text"] = all(
        res.cell(r, issue_col).value for r in range(2, res.max_row + 1))
    failed = [k for k, v in checks.items() if not v]
    if failed:
        raise RuntimeError(f"Post-write validation failed: {failed}")
    return checks


def main(argv=None):
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("input", help="Input .xlsx containing a 'Projects' worksheet")
    p.add_argument("-o", "--output", help=f"Output path (default: <input dir>/{DEFAULT_OUTPUT_NAME})")
    p.add_argument("--as-of", help="Evaluation date YYYY-MM-DD (default: today, UTC)")
    p.add_argument("--report-json", help="Optional path for a machine-readable run report")
    a = p.parse_args(argv)

    try:
        as_of = date.fromisoformat(a.as_of) if a.as_of else datetime.now(timezone.utc).date()
    except ValueError:
        print(f"ERROR: --as-of must be YYYY-MM-DD, got {a.as_of!r}", file=sys.stderr)
        return 2
    output = a.output or str(Path(a.input).with_name(DEFAULT_OUTPUT_NAME))
    try:
        s = process_workbook(a.input, output, as_of, a.report_json)
    except SchemaError as e:
        print(f"ERROR: {e}", file=sys.stderr)
        return 2
    except RuntimeError as e:
        print(f"ERROR: {e}", file=sys.stderr)
        return 3

    print(f"Output: {s['output_file']}")
    print(f"Evaluation date: {s['evaluation_date']}")
    print(f"Total projects: {s['total_projects']} | with issues: {s['projects_with_issues']} | "
          f"over budget: {s['over_budget_projects']} | overdue: {s['overdue_projects']}")
    for e in s["exceptions"]:
        print(f"  row {e['source_row']} {e['project_id'] or '(no ID)'}: {e['issues']}")
    print("Validation: " + ", ".join(f"{k}={v}" for k, v in s["validation"].items()))
    return 0


if __name__ == "__main__":
    sys.exit(main())
